========================================================================
Bunnies vs. Bunnies
By Jordan Magnuson
========================================================================

CONTROLS:
Arrow keys to move, jump (space can also be used to jump)

TIP:
If you find a level to difficult or frustrating you can press "N"
to skip to the next level, though this key is not intended for
normal play. There are only five levels total in the game.

SOURCE:
The source code and graphics for Bunnies vs. Bunnies are available for 
you to use in any way you want, free of charge. You can download the 
source and graphics (Game Maker 8 gmk file) from: 

http://www.necessarygames.com/node/83/


For my latest games, projects, and reviews, check out my website:

http://www.necessarygames.com/


Thanks for taking the time to play this game,

Jordan Magnuson 
NecessaryGames.com