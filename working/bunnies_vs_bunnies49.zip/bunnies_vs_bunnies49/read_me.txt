The source code and graphics for Bunnies vs. Bunnies are available for 
you to use in any way you want, free of charge. You can download the 
source and graphics (Game Maker 7 file) from: 

http://www.necessarygames.com/node/83/

For my latest games, projects, and reviews, check out my website:

http://www.necessarygames.com/


Thanks for taking the time to play this game,

Jordan Magnuson